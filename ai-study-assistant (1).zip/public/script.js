// State and Elements
let notes = [];
let editingNoteId = null;

const notesList = document.getElementById('notesList');
const notesCount = document.getElementById('notesCount');
const addNoteForm = document.getElementById('addNoteForm');
const formTitle = document.getElementById('formTitle');
const submitBtn = document.getElementById('submitBtn');
const cancelEditBtn = document.getElementById('cancelEditBtn');

const chatMessages = document.getElementById('chatMessages');
const aiForm = document.getElementById('aiForm');
const aiInput = document.getElementById('aiInput');
const summarizeAllBtn = document.getElementById('summarizeAllBtn');
const clearHistoryBtn = document.getElementById('clearHistoryBtn');

// Helper for UI Feedback
export function showToast(message, isError = false) {
    const toast = document.createElement('div');
    toast.className = `fixed bottom-8 right-8 px-6 py-3 rounded-lg text-xs font-bold uppercase tracking-widest shadow-2xl z-[100] toast-in ${isError ? 'bg-red-600 text-white' : 'bg-gray-900 text-white'}`;
    toast.textContent = message;
    document.body.appendChild(toast);
    
    // Remove after 3s
    setTimeout(() => {
        toast.style.opacity = '0';
        toast.style.transform = 'translateY(10px)';
        toast.style.transition = 'all 0.5s';
        setTimeout(() => toast.remove(), 500);
    }, 3000);
}

// User Management
async function checkUserStatus() {
    try {
        const response = await fetch('/api/me');
        const user = await response.json();
        const userInfo = document.getElementById('userInfo');
        
        if (user && userInfo) {
            userInfo.innerHTML = `
                <span class="opacity-40">User: ${user.username}</span>
                <button id="logoutBtn" class="opacity-40 hover:opacity-100 transition-opacity uppercase text-[10px] font-bold border-b border-[#1A1A1A]">Logout</button>
            `;
            document.getElementById('logoutBtn').addEventListener('click', async () => {
                await fetch('/api/logout', { method: 'POST' });
                window.location.reload();
            });
        } else if (!user && !['/login.html', '/signup.html', '/index.html', '/'].includes(window.location.pathname)) {
            // Only redirect if they are on a protected page
            // For simplicity in this demo, let's just let them see index.html
        }
    } catch (err) {
        console.error('Err checking status:', err);
    }
}

// Notes Logic
async function fetchNotes() {
    if (!notesList) return;
    try {
        const response = await fetch('/notes');
        if (response.status === 401) {
            notesList.innerHTML = `
                <div class="py-12 text-center">
                    <p class="opacity-40 italic font-serif mb-4">You must be authenticated to view the archives.</p>
                    <a href="login.html" class="primary">Login to Archive</a>
                </div>
            `;
            return;
        }
        const data = await response.json();
        if (response.ok) {
            notes = data;
            renderNotes();
        } else {
            showToast(data.error || 'Failed to fetch notes', true);
        }
    } catch (err) {
        console.error('Error fetching notes:', err);
        showToast('Connection error while fetching notes', true);
    }
}

function renderNotes() {
    if (!notesList) return;
    if (notesCount) notesCount.textContent = notes.length;
    
    if (notes.length === 0) {
        notesList.innerHTML = `
            <div class="py-12 text-center opacity-40 italic font-serif">
                The archives are currently empty. Create your first entry to begin.
            </div>
        `;
        return;
    }

    notesList.innerHTML = notes.map(note => `
        <div class="note-card pb-12">
            <div class="flex justify-between items-start mb-6">
                <div class="space-y-1">
                    <p class="text-[10px] uppercase tracking-widest opacity-40 font-bold">Archive Entry #${note.id}</p>
                    <h3 class="font-serif text-3xl italic leading-none cursor-pointer hover:underline" onclick="startEditing(${note.id})">${note.title}</h3>
                </div>
                <div class="flex gap-2">
                    <button onclick="summarizeNote(${note.id})" class="secondary">Summarize</button>
                    <button onclick="startEditing(${note.id})" class="secondary">Edit</button>
                    <button onclick="deleteNote(${note.id})" class="secondary text-red-500 border-red-100 hover:bg-red-50">Delete</button>
                </div>
            </div>
            <p class="text-sm leading-relaxed text-[#444] mb-6 font-serif whitespace-pre-wrap">${note.content}</p>
            <div class="h-px w-16 bg-[#1A1A1A] mb-4"></div>
            <div class="flex gap-4">
                <button onclick="explainNote(${note.id})" class="text-[9px] uppercase tracking-widest font-bold opacity-40 hover:opacity-100 italic">Request AI Explanation →</button>
            </div>
        </div>
    `).join('');
}

if (addNoteForm) {
    addNoteForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const title = document.getElementById('noteTitle').value.trim();
        const content = document.getElementById('noteContent').value.trim();
        
        if (!title || !content) {
            showToast('Title and content are required', true);
            return;
        }

        const url = editingNoteId ? `/updateNote/${editingNoteId}` : '/addNote';
        const method = editingNoteId ? 'PUT' : 'POST';

        try {
            submitBtn.disabled = true;
            submitBtn.textContent = 'Storing...';
            
            const response = await fetch(url, {
                method: method,
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ title, content })
            });
            const data = await response.json();
            
            if (response.ok) {
                showToast(editingNoteId ? 'Archive updated successfully' : 'Entry logged successfully');
                resetForm();
                fetchNotes();
            } else {
                showToast(data.error || 'Failed to save entry', true);
            }
        } catch (err) {
            console.error('Error saving note:', err);
            showToast('Connection error while saving', true);
        } finally {
            submitBtn.disabled = false;
            submitBtn.textContent = editingNoteId ? 'Update Archive' : 'Log Entry';
        }
    });

    if (cancelEditBtn) {
        cancelEditBtn.addEventListener('click', resetForm);
    }
}

function resetForm() {
    editingNoteId = null;
    document.getElementById('noteTitle').value = '';
    document.getElementById('noteContent').value = '';
    if (formTitle) formTitle.textContent = 'Create Entry';
    if (submitBtn) submitBtn.textContent = 'Log Entry';
    if (cancelEditBtn) cancelEditBtn.classList.add('hidden');
}

window.startEditing = (id) => {
    const note = notes.find(n => n.id === id);
    if (!note) return;

    editingNoteId = id;
    document.getElementById('noteTitle').value = note.title;
    document.getElementById('noteContent').value = note.content;
    
    if (formTitle) formTitle.textContent = 'Revise Entry';
    if (submitBtn) submitBtn.textContent = 'Update Archive';
    if (cancelEditBtn) cancelEditBtn.classList.remove('hidden');
    
    addNoteForm.scrollIntoView({ behavior: 'smooth' });
};

window.deleteNote = async (id) => {
    if (!confirm('Are you certain you wish to remove this entry from the archive?')) return;
    try {
        const response = await fetch(`/deleteNote/${id}`, { method: 'DELETE' });
        if (response.ok) {
            showToast('Entry removed from archive');
            fetchNotes();
            if (editingNoteId === id) resetForm();
        } else {
            const data = await response.json();
            showToast(data.error || 'Failed to delete entry', true);
        }
    } catch (err) {
        console.error('Error deleting note:', err);
        showToast('Connection error while deleting', true);
    }
};

// AI Logic
async function callAI(prompt) {
    try {
        const response = await fetch('/api/ai/chat', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ prompt })
        });
        const data = await response.json();
        if (response.ok) {
            return data.text;
        } else {
            return `System Error: ${data.error || 'Unknown error'}`;
        }
    } catch (err) {
        console.error('AI Error:', err);
        return 'System Unavailable. Please verify your connection to the Inquiry Engine.';
    }
}

function appendMessage(text, isUser = false) {
    if (!chatMessages) return;
    const div = document.createElement('div');
    div.className = isUser ? 'flex gap-4 justify-end text-right' : 'flex gap-4 slide-in';
    
    if (isUser) {
        div.innerHTML = `
            <div class="pt-1">
                <p class="text-[10px] uppercase tracking-widest opacity-40 mb-2">You</p>
                <div class="user-message">${text}</div>
            </div>
        `;
    } else {
        div.innerHTML = `
            <div class="w-8 h-8 rounded-full border border-[#1A1A1A] flex items-center justify-center shrink-0 text-[10px] font-bold">AI</div>
            <div class="pt-1 text-left">
                <p class="text-[10px] uppercase tracking-widest opacity-40 mb-2">Response Engine</p>
                <div class="ai-message font-serif italic">${text}</div>
            </div>
        `;
    }
    
    chatMessages.appendChild(div);
    chatMessages.scrollTop = chatMessages.scrollHeight;
}

async function loadChatHistory() {
    if (!chatMessages) return;
    try {
        const response = await fetch('/api/ai/history');
        const history = await response.json();
        if (response.ok && history.length > 0) {
            // Clear default message if history exists
            chatMessages.innerHTML = '';
            history.forEach(msg => {
                appendMessage(msg.content, msg.role === 'user');
            });
        }
    } catch (err) {
        console.error('Error loading history:', err);
    }
}

if (clearHistoryBtn) {
    clearHistoryBtn.addEventListener('click', async () => {
        if (!confirm('Are you sure you want to erase all conversation history?')) return;
        try {
            const response = await fetch('/api/ai/history', { method: 'DELETE' });
            if (response.ok) {
                chatMessages.innerHTML = `
                    <div class="flex gap-4">
                        <div class="w-8 h-8 rounded-full border border-[#1A1A1A] flex items-center justify-center shrink-0 text-[10px] font-bold">AI</div>
                        <div class="pt-1 text-left">
                            <p class="text-[10px] uppercase tracking-widest opacity-40 mb-2">Response Engine</p>
                            <div class="ai-message font-serif italic">Salutations. The archives have been purged. How shall we proceed with your studies?</div>
                        </div>
                    </div>
                `;
                showToast('History purged');
            }
        } catch (err) {
            showToast('Failed to clear history', true);
        }
    });
}

if (aiForm) {
    aiForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const question = aiInput.value.trim();
        if (!question) return;

        appendMessage(question, true);
        aiInput.value = '';
        
        // Show loading state
        const loadingId = 'ai-loading-' + Date.now();
        const loadingDiv = document.createElement('div');
        loadingDiv.id = loadingId;
        loadingDiv.className = 'flex gap-4 animate-pulse';
        loadingDiv.innerHTML = `
            <div class="w-8 h-8 rounded-full border border-[#1A1A1A] flex items-center justify-center shrink-0 text-[10px] font-bold opacity-20">AI</div>
            <div class="pt-1">
                <p class="text-[10px] uppercase tracking-widest opacity-20 mb-2">Processing...</p>
                <div class="h-4 w-32 bg-gray-200 rounded"></div>
            </div>
        `;
        chatMessages.appendChild(loadingDiv);
        chatMessages.scrollTop = chatMessages.scrollHeight;

        const answer = await callAI(question);
        
        // Remove loading and append answer
        document.getElementById(loadingId).remove();
        appendMessage(answer, false);
    });
}

// Global functions for note actions
window.summarizeNote = async (id) => {
    const note = notes.find(n => n.id === id);
    if (!note) return;
    localStorage.setItem('ai_context', `Please provide a concise, editorial style summary of the following entry: ${note.title}\n\n${note.content}`);
    window.location.href = 'ai.html';
};

window.explainNote = async (id) => {
    const note = notes.find(n => n.id === id);
    if (!note) return;
    localStorage.setItem('ai_context', `Explain this topic in detail, maintaining an academic yet accessible tone: ${note.title}\n\n${note.content}`);
    window.location.href = 'ai.html';
};

if (summarizeAllBtn) {
    summarizeAllBtn.addEventListener('click', async () => {
        const response = await fetch('/notes');
        const allNotes = await response.json();
        if (allNotes.length === 0) {
            showToast('The archives are currently empty', true);
            return;
        }
        const fullContent = allNotes.map(n => `Title: ${n.title}\nContent: ${n.content}`).join('\n\n---\n\n');
        
        appendMessage("Synthesizing the entire archive...", true);
        const summary = await callAI(`Provide an overarching synthesis of these research notes, identifying common themes and critical insights:\n\n${fullContent}`);
        appendMessage(summary, false);
    });
}

async function checkContext() {
    const context = localStorage.getItem('ai_context');
    if (context && chatMessages) {
        localStorage.removeItem('ai_context');
        appendMessage("I have selected an entry for synthesis/explanation.", true);
        
        // Brief delay for natural feel
        setTimeout(async () => {
            const response = await callAI(context);
            appendMessage(response, false);
        }, 500);
    }
}

// Init
checkUserStatus();
fetchNotes();
loadChatHistory();
checkContext();
