# AI Study Assistant

A full-stack web application designed to help users manage study notes and leverage AI for explanations and summaries.

## Features
- **Notes Management**: Add, view, and delete study notes (SQLite).
- **AI Chat**: Ask any study-related question.
- **AI Summary**: Summarize your entire library or individual notes.
- **AI Explanations**: Get detailed explanations for topics in your notes.

## Tech Stack
- **Frontend**: Vanilla HTML5, CSS3 (Tailwind CSS), JavaScript (ES Modules).
- **Backend**: Node.js, Express.
- **Database**: SQLite3.
- **AI**: Gemini AI API (@google/genai).

## Installation
```bash
npm install
node server.js
```

## Environment Variables
- `GEMINI_API_KEY`: Your Google Gemini API Key.
- `PORT`: Server port (defaults to 3000).
