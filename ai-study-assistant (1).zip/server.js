const express = require('express');
const cors = require('cors');
const path = require('path');
const session = require('express-session');
const bcrypt = require('bcryptjs');
const db = require('./db');
const { GoogleGenerativeAI } = require('@google/genai');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

// Initialize Gemini
const genAI = process.env.GEMINI_API_KEY ? new GoogleGenerativeAI(process.env.GEMINI_API_KEY) : null;
const model = genAI ? genAI.getGenerativeModel({ model: "gemini-1.5-flash" }) : null;

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));
app.use(session({
  secret: 'study-assistant-secret',
  resave: false,
  saveUninitialized: false,
  cookie: { secure: false } // Set to true if using HTTPS
}));

// Auth Middleware
const isAuthenticated = (req, res, next) => {
  if (req.session.userId) {
    next();
  } else {
    res.status(401).json({ error: 'Unauthorized. Please log in.' });
  }
};

// Helper for error responses
const handleError = (res, err, status = 500) => {
  console.error(err);
  res.status(status).json({ error: err.message || 'An unexpected error occurred' });
};

// Auth Routes
app.post('/api/register', async (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) return res.status(400).json({ error: 'Username and password are required' });
  
  try {
    const hashedPassword = await bcrypt.hash(password, 10);
    db.run('INSERT INTO users (username, password) VALUES (?, ?)', [username, hashedPassword], function(err) {
      if (err) {
        if (err.message.includes('UNIQUE')) return res.status(400).json({ error: 'Username already exists' });
        return handleError(res, err);
      }
      res.json({ message: 'User registered' });
    });
  } catch (err) {
    handleError(res, err);
  }
});

app.post('/api/login', (req, res) => {
  const { username, password } = req.body;
  db.get('SELECT * FROM users WHERE username = ?', [username], async (err, user) => {
    if (err) return handleError(res, err);
    if (!user) return res.status(400).json({ error: 'Invalid credentials' });
    
    const match = await bcrypt.compare(password, user.password);
    if (!match) return res.status(400).json({ error: 'Invalid credentials' });
    
    req.session.userId = user.id;
    res.json({ message: 'Login successful', username: user.username });
  });
});

app.post('/api/logout', (req, res) => {
  req.session.destroy();
  res.json({ message: 'Logged out' });
});

app.get('/api/me', (req, res) => {
  if (req.session.userId) {
    db.get('SELECT username FROM users WHERE id = ?', [req.session.userId], (err, user) => {
      if (err) return handleError(res, err);
      res.json(user);
    });
  } else {
    res.json(null);
  }
});

// AI Routes (Now in Backend)
app.get('/api/ai/history', isAuthenticated, (req, res) => {
  db.all('SELECT * FROM chat_history WHERE user_id = ? ORDER BY timestamp ASC', [req.session.userId], (err, rows) => {
    if (err) return handleError(res, err);
    res.json(rows);
  });
});

app.post('/api/ai/chat', isAuthenticated, async (req, res) => {
  if (!model) {
    return res.status(503).json({ error: 'AI service not configured on server' });
  }

  const { prompt } = req.body;
  if (!prompt) {
    return res.status(400).json({ error: 'Prompt is required' });
  }

  try {
    const result = await model.generateContent(prompt);
    const response = await result.response;
    const aiText = response.text();

    // Save to history
    db.serialize(() => {
      db.run('INSERT INTO chat_history (user_id, role, content) VALUES (?, ?, ?)', [req.session.userId, 'user', prompt]);
      db.run('INSERT INTO chat_history (user_id, role, content) VALUES (?, ?, ?)', [req.session.userId, 'ai', aiText]);
    });

    res.json({ text: aiText });
  } catch (err) {
    handleError(res, err);
  }
});

app.delete('/api/ai/history', isAuthenticated, (req, res) => {
  db.run('DELETE FROM chat_history WHERE user_id = ?', [req.session.userId], (err) => {
    if (err) return handleError(res, err);
    res.json({ message: 'History cleared' });
  });
});

// Notes API Routes
app.get('/notes', isAuthenticated, (req, res) => {
  db.all('SELECT * FROM notes WHERE user_id = ? ORDER BY id DESC', [req.session.userId], (err, rows) => {
    if (err) return handleError(res, err);
    res.json(rows);
  });
});

app.post('/addNote', isAuthenticated, (req, res) => {
  const { title, content } = req.body;
  if (!title?.trim() || !content?.trim()) {
    return res.status(400).json({ error: 'Title and content are required' });
  }
  db.run('INSERT INTO notes (user_id, title, content) VALUES (?, ?, ?)', [req.session.userId, title.trim(), content.trim()], function(err) {
    if (err) return handleError(res, err);
    res.json({ id: this.lastID, title, content });
  });
});

app.delete('/deleteNote/:id', isAuthenticated, (req, res) => {
  const { id } = req.params;
  db.run('DELETE FROM notes WHERE id = ? AND user_id = ?', [id, req.session.userId], function(err) {
    if (err) return handleError(res, err);
    if (this.changes === 0) return res.status(404).json({ error: 'Note not found' });
    res.json({ message: 'Note deleted' });
  });
});

app.put('/updateNote/:id', isAuthenticated, (req, res) => {
  const { id } = req.params;
  const { title, content } = req.body;
  
  if (!title?.trim() || !content?.trim()) {
    return res.status(400).json({ error: 'Title and content are required' });
  }

  db.run('UPDATE notes SET title = ?, content = ? WHERE id = ? AND user_id = ?', [title.trim(), content.trim(), id, req.session.userId], function(err) {
    if (err) return handleError(res, err);
    if (this.changes === 0) return res.status(404).json({ error: 'Note not found' });
    res.json({ id, title, content });
  });
});

app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`Server running on http://0.0.0.0:${PORT}`);
});
